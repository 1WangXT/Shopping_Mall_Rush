package cn.wolfcode.mq;

/**
 * Created by lanxw
 */
public class MQConstant {
    //登录事件的消息队列
    public static final String LOGIN_TOPIC = "LOGIN_TOPIC";
}

package cn.wolfcode.web.advice;

import cn.wolfcode.common.exception.CommonControllerAdvice;
import org.springframework.web.bind.annotation.ControllerAdvice;

/**
 * Created by wolfcode-lanxw
 */
@ControllerAdvice
public class PayControllerAdvice extends CommonControllerAdvice {
}

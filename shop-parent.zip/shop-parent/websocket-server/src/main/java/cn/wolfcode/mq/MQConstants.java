package cn.wolfcode.mq;

/**
 * Created by wolfcode-lanxw
 */
public class MQConstants {
    public static final String ORDER_RESULT_TOPIC = "ORDER_RESULT_TOPIC";

}

package cn.wolfcode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by lanxw
 */
@SpringBootApplication
public class CanalClientApp {
    public static void main(String[] args) {
        SpringApplication.run(CanalClientApp.class,args);
    }
}

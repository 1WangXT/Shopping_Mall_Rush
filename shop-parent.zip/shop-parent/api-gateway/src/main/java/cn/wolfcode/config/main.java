package cn.wolfcode.config;

import java.util.Scanner;

import java.util.Stack;

public class main {

    public static class ListNode {
        int val;
        ListNode next = null;

        ListNode(int val) {
            this.val = val;
        }
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        // 注意 hasNext 和 hasNextLine 的区别
        String str = in.next().toString();
        String[] arr = str.split(",");
        int[] ints = new int[arr.length];
        for (int j = 0; j < ints.length; j++) {
            ints[j] = Integer.parseInt(arr[j]);
        }

        Stack<ListNode> stack = new Stack<>();
        ListNode head = new ListNode(0);
        ListNode p = head;
        for (int i = 0; i < ints.length; i++) {
            p.next = new ListNode(ints[i]);
            p = p.next;
            stack.add(p);

        }
        head = head.next;
        p = ReverseList(head);

    }

    public static ListNode ReverseList(ListNode head) {
        if (head == null) return null;
        ListNode pre = null;
        ListNode next = null;
        while (head != null) {
            next = head.next;
            if(next==null){
                System.out.println(head.val);
            }
            else{
                System.out.println(head.val+",");
            }
            head.next = pre;

            pre = head;
            head = next;
        }
        return pre;
    }
}
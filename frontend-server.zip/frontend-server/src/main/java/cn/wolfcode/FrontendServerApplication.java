package cn.wolfcode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrontendServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(FrontendServerApplication.class, args);
    }

}
